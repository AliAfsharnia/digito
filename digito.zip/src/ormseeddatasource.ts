import { DataSource } from "typeorm";
import ormseedconfig from './ormseedconfig';

export default new DataSource(ormseedconfig);