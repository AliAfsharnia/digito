import { Controller } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';

@ApiTags("payment")
@Controller('payment')
export class PaymentController {}
